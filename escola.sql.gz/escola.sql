-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: escola
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alumnes`
--

DROP TABLE IF EXISTS `alumnes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnes` (
  `NumMatricula` smallint unsigned NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Telefon` int unsigned DEFAULT NULL,
  `DataNaixement` date NOT NULL,
  PRIMARY KEY (`NumMatricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnes`
--

LOCK TABLES `alumnes` WRITE;
/*!40000 ALTER TABLE `alumnes` DISABLE KEYS */;
INSERT INTO `alumnes` VALUES (4758,'Josep',555666555,'2004-11-14'),(4759,'Maria',123123123,'2004-11-14'),(4860,'Raül',567567567,'2002-02-28'),(5061,'Ariadna',543543543,'1992-01-17'),(6258,'Jesús',156156156,'2005-12-25');
/*!40000 ALTER TABLE `alumnes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignatures`
--

DROP TABLE IF EXISTS `assignatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignatures` (
  `Codi` int unsigned NOT NULL AUTO_INCREMENT,
  `Nom` varchar(20) DEFAULT NULL,
  `ID_Professor` int unsigned NOT NULL,
  PRIMARY KEY (`Codi`),
  KEY `assignatures_fk_professors` (`ID_Professor`),
  CONSTRAINT `assignatures_fk_professors` FOREIGN KEY (`ID_Professor`) REFERENCES `professors` (`ID_P`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignatures`
--

LOCK TABLES `assignatures` WRITE;
/*!40000 ALTER TABLE `assignatures` DISABLE KEYS */;
INSERT INTO `assignatures` VALUES (1,'C++',1),(2,'SQL',2),(3,'Xarxes',3),(4,'Criptografia',4),(5,'Python',3);
/*!40000 ALTER TABLE `assignatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matriculacions`
--

DROP TABLE IF EXISTS `matriculacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matriculacions` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `MatriculaAlumne` smallint unsigned NOT NULL,
  `CodiAssignatura` int unsigned NOT NULL,
  `AnyAcademic` int unsigned DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `matriculacions_fk_alumnes` (`MatriculaAlumne`),
  KEY `matriculacions_fk_assignatures` (`CodiAssignatura`),
  CONSTRAINT `matriculacions_fk_alumnes` FOREIGN KEY (`MatriculaAlumne`) REFERENCES `alumnes` (`NumMatricula`),
  CONSTRAINT `matriculacions_fk_assignatures` FOREIGN KEY (`CodiAssignatura`) REFERENCES `assignatures` (`Codi`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matriculacions`
--

LOCK TABLES `matriculacions` WRITE;
/*!40000 ALTER TABLE `matriculacions` DISABLE KEYS */;
INSERT INTO `matriculacions` VALUES (1,4759,4,20242025),(2,4860,4,20232024),(3,5061,3,20202021),(4,5061,2,20202021),(5,6258,4,20212022);
/*!40000 ALTER TABLE `matriculacions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professors`
--

DROP TABLE IF EXISTS `professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professors` (
  `ID_P` int unsigned NOT NULL AUTO_INCREMENT,
  `NIF_P` char(9) DEFAULT NULL,
  `Nom` varchar(20) DEFAULT NULL,
  `Telefon` int unsigned DEFAULT NULL,
  `Especialitat` enum('Programació','Ciberseguretat','Bases de dades') DEFAULT NULL,
  PRIMARY KEY (`ID_P`),
  UNIQUE KEY `professors_unique` (`NIF_P`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professors`
--

LOCK TABLES `professors` WRITE;
/*!40000 ALTER TABLE `professors` DISABLE KEYS */;
INSERT INTO `professors` VALUES (1,'12312312A','Edu',666555444,'Programació'),(2,'45645645S','Marta',444333222,'Bases de dades'),(3,'98798798T','Claudio',159159159,'Ciberseguretat'),(4,'36536536U','Eva',999888999,'Ciberseguretat'),(5,'87987987M','David',123456789,'Programació');
/*!40000 ALTER TABLE `professors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-27 13:13:50
